A list of 21 separate expressions is contained in testcases.txt.

The expected answers are contained, line by line, in results.txt.
