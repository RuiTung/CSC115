public class StringStackException extends Exception {
    public StringStackException(String message) {
        super(message);
    }
}
