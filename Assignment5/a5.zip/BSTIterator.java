import java.util.LinkedList;

/**
 * @author Mike Zastre, UVic
 *
 * Part of CSC 115, Summer 2015, Assignment #5
 */

public class BSTIterator implements java.util.Iterator<WordRefs> {
    private BSTRefBased t;
    private WordRefs currentItem;
    private LinkedList<WordRefs> list;

    public BSTIterator(BSTRefBased t) {
        this.t = t;
        currentItem = null;
        list = new LinkedList<>();
        setInorder();
    }

    public boolean hasNext() {
        return false;
    }

    public WordRefs next() throws java.util.NoSuchElementException {
        return null;
    }

    public void remove() throws UnsupportedOperationException {
        throw new UnsupportedOperationException();
    }

    public void setPreorder() {
    }

    public void setInorder() {
    }

    public void setPostorder() {
    }

    private void preorder(TreeNode node) {
    }

    private void inorder(TreeNode node) {
    }

    private void postorder(TreeNode node) {
    }
}
