There are three test outputs provided. They
have been generated as follows using a bash shell:

java A3driver --dict=files/small.txt --phrase="Justin Trudeau" --maxwords=4 | sort > files/test01.txt

java A3driver --dict=files/medium.txt --phrase="Justin Trudeau" --maxwords=3 | sort > files/test02.txt

java A3driver --dict=files/large.txt --phrase="Justin Trudeau" --maxwords=2 | sort > files/test03.txt

Note the last test may take a bit of time to execute.
