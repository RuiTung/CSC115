/* Add appropriate comments! */
class TaskListNodeAlt {
    Task task;
    TaskListNodeAlt next;

    TaskListNodeAlt(Task task) {
        this.task = task;
        this.next = null;
    }
}
